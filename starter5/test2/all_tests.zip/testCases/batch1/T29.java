// % operator on int literals

class Main extends Lib {
  public void main() {
    super.printInt(52%5);
  }
}
