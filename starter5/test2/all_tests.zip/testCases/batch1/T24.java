// > operator on equal values

class Main extends Lib {
  public void main() {
    super.printBool(4027>4027);
  }
}

