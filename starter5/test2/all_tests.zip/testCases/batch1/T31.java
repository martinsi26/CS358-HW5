// compare string lit to null (!=)

class Main extends Lib {
  public void main() {
    super.printBool("abc" != null);
  }
}
