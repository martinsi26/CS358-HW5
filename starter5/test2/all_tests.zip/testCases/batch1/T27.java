// == operator on identical string literals

class Main extends Lib {
  public void main() {
    super.printBool("abc"=="abc");
  }
}
