// print a string literal
class Main extends Lib {
  public void main() {
    super.printStr("Here are the results\n");
  }
}

