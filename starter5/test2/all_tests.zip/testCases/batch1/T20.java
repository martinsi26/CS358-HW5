// != operator on equal int literals

class Main extends Lib {
  public void main() {
    super.printBool(4027!=4027);
  }
}

