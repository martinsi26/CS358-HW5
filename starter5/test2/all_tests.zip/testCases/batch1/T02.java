// print an int literal
class Main extends Lib {
  public void main() {
    super.printInt(4764);
  }
}


