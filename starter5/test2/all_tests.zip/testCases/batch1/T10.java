// != operator on unequal int literals


class Main extends Lib {
  public void main() {
    super.printBool(3!=52);
  }
}
