// != operator on identical string literals

class Main {
  public void main() {
    new Lib().printBool("abc" != "abc");
  }
}
