// compare string lit to null (==)

class Main {
  public void main() {
    new Lib().printBool("abc" == null);
  }
}
