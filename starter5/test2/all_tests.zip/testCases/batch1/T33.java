// print boolean literal: false

class Main extends Lib {
  public void main() {
      super.printBool(false);
  }
}
