// != operator on non-equal string literals

class Main extends Lib {
  public void main() {
    super.printBool("abc" != "def");
  }
}

