// < operator on unequal int literals
//package batch1;

class Main extends Lib {
  public void main() {
    super.printBool(3<52);
  }
}
