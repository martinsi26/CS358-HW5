// print boolean literal: true

class Main extends Lib {
  public void main() {
      super.printBool(true);
  }
}
