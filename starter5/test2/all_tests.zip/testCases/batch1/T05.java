// * operator with int literals

class Main extends Lib {
  public void main() {
    super.printInt(3*52);
  }
}
