// To test that v-table labels are not too simple (e.g., just class name)
class Main extends Lib {
  public void main() {
    super.printStr("Complete!\n");
  }
}
class mainn {
}
