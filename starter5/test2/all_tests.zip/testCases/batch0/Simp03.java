class Main extends Lib {
  public void main() {
    printInt(345);
  }
}
