class Main extends Lib {
  public void main() {
          int xyz = 321;
          int abc = xyz+18;
          super.printInt(abc+17);
          super.printStr("\n");
  }
}
