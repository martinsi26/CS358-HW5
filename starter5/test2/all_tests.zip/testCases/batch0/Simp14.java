class Main extends Lib {
  public void main() {
          int xyz = 321;
          int abc = xyz+18;
	  int val = 23-xyz;
	  String s = " ... \n";
          super.printInt(29+val);
          super.printStr(s);
  }
}
