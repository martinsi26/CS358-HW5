// print string literal

class Main extends Lib {
  public void main() {
    super.printStr("This is a string.\n");
  }
}
