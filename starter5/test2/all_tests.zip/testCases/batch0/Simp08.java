class Main extends Lib {
  public void main() {
      int val = 27;
      super.printInt(val+263);
  }
}
