class Main extends Lib {
  public void main() {
      printStr("Hello.\n");
  }
}
