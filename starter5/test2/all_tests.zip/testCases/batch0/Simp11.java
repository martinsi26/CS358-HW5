class Main extends Lib {
  public void main() {
      int val = 27;
      printInt(val-263);
  }
}
