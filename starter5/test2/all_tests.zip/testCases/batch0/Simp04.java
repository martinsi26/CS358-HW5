class Main extends Lib {
  public void main() {
      super.printStr("Hello.\n");
  }
}
