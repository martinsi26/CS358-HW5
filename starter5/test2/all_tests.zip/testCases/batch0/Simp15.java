class Main extends Lib {
  public void main() {
          int xyz = 321;
          int abc = xyz+18;
	  int val = 23-xyz;
	  String s = " ... \n";
          printInt(29+val);
          printStr(s);
  }
}
