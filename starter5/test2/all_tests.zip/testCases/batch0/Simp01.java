class Main {
  public void main() {
  }
}
