class Main extends Lib {
  public void main() {
    super.printInt(345);
  }
}
