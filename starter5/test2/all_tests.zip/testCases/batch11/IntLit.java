// prints int literals and string literals

class Main {
	public void main() {
		Lib lib = new Lib();
		lib.printInt(0); lib.printStr("\n");
		lib.printInt(23); lib.printStr("\n");
		lib.printInt(2147483647); lib.printStr("\n");
		lib.printInt(3262923); lib.printStr("\n");
	}
	
}
