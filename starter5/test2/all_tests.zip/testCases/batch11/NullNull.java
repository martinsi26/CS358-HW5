// testing if null == null

class Main extends Lib {
	public void main() {
		if (null == null) {
			super.printStr("Hello");
		}
	}
}
