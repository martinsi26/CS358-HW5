// simple for loop with ints

class Main extends Lib {
  public void main() {
    for (int i = 22; i <= 33; i++) {
      super.printInt(i);
      super.printStr("\n");
    }
  }
}

