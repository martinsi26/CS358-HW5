// nested if, method-call conditions

class Main extends Lib {
    public void main() {
	int z = 5;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 15;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 25;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 35;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 45;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 55;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 65;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}

	z = 75;
	if (between(z,0,39)) {
	    if(between(z,0,19)) {
		if (between(z,0,9)) {
		    super.printStr("case 1");
		}
		else {
		    super.printStr("case 2");
		}
	    }
	    else {
		if (between(z,20,29)) {
		    super.printStr("case 3");
		}
		else {
		    super.printStr("case 4");
		}
	    }
	}
	else {
	    if(between(z,40,59)) {
		if (between(z,40,49)) {
		    super.printStr("case 5");
		}
		else {
		    super.printStr("case 6");
		}
	    }
	    else {
		if (between(z,60,69)) {
		    super.printStr("case 7");
		}
		else {
		    super.printStr("case 8");
		}
	    }
	}
    }

    public boolean between(int val, int min, int max) {
	boolean rtnVal = true;
	if (val < min) rtnVal = false;
	if (val > max) rtnVal = false;
	return rtnVal;
    }
}
