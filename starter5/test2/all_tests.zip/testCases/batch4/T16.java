// cascaded if

class Main extends Lib {
  public void main() {
      int z = 5;
      if (z == 0) {
	  super.printStr("It's a 0.\n");
      }
      else if (z == 1) {
	  super.printStr("It's a 1.\n");
      }
      else if (z == 2) {
	  super.printStr("It's a 2.\n");
      }
      else if (z == 3) {
	  super.printStr("It's a 3.\n");
      }
      else if (z == 4) {
	  super.printStr("It's a 4.\n");
      }
      else if (z == 5) {
	  super.printStr("It's a 5.\n");
      }
      else if (z == 6) {
	  super.printStr("It's a 6.\n");
      }
      else if (z == 7) {
	  super.printStr("It's a 7.\n");
      }
      else if (z == 8) {
	  super.printStr("It's a 8.\n");
      }
      else {
	  super.printStr("It's something else.\n");
      }
      int zz = 500;
      if (zz == 0) {
	  super.printStr("It's a 0.\n");
      }
      else if (zz == 1) {
	  super.printStr("It's a 1.\n");
      }
      else if (zz == 2) {
	  super.printStr("It's a 2.\n");
      }
      else if (zz == 3) {
	  super.printStr("It's a 3.\n");
      }
      else if (zz == 4) {
	  super.printStr("It's a 4.\n");
      }
      else if (zz == 5) {
	  super.printStr("It's a 5.\n");
      }
      else if (zz == 6) {
	  super.printStr("It's a 6.\n");
      }
      else if (zz == 7) {
	  super.printStr("It's a 7.\n");
      }
      else if (zz == 8) {
	  super.printStr("It's a 8.\n");
      }
      else {
	  super.printStr("It's something else.\n");
      }


  }
}
