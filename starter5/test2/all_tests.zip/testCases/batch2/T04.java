// local boolean variables

class Main extends Lib {
    public void main() {
	boolean z = true;
	boolean y = !z;
	boolean x = !!!!!y;
	super.printBool(z);
	super.printBool(y);
	super.printBool(x);
    }
}

