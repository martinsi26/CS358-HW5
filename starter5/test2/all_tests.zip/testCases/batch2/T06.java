// array length

class Main extends Lib {
    public void main() {
	int[] z = new int[53];
	Object[] y = new Object[2374];
	super.printInt(z.length);
	super.printInt(y.length);
    }
}
