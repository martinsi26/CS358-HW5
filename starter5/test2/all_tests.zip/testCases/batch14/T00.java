// cast tests

class Main extends Lib {
  public void main() {
      C1 var1 = null;
      C1 abc11 = new C1();
      var1 = (C1)abc11;
      printStr("Jumbles of Bumbles!\n");
  }
}

class C1 {
}
