// library method: substring, printStr

class Main extends Lib {
  public void main() {
    super.printStr(
       "Now is the time for all good men to come to McDonald's".substring(
                13,
                21));
    super.printStr("\n");
  }
}
