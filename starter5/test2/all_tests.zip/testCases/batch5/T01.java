// library method: charAt

class Main extends Lib {
  public void main() {
    super.printInt("k".charAt(0));
    super.printStr("\n");
  }
}

