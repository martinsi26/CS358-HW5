// library method: intToChar

class Main extends Lib {
  public void main() {
    super.printStr(super.intToChar(67));
    super.printStr("\n");
  }
}

