// library method: concat, printStr

class Main extends Lib {
  public void main() {
    super.printStr(
      "Moe".concat("Larry").concat("And".concat("Curly")));
    super.printStr("\n");
  }
}
