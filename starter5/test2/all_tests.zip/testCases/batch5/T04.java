// library method: readLine, charAt

class Main extends Lib {
  public void main() {
    String str = super.readLine();
    int c1 = str.charAt(0);
    int c2 = str.charAt(1);
    int c3 = str.charAt(2);
    int c4 = str.charAt(3);
    super.printInt(c4);super.printStr("\n");
    super.printInt(c3);super.printStr("\n");
    super.printInt(c2);super.printStr("\n");
    super.printInt(c1);super.printStr("\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");

    super.printStr("found a line: <");
    super.printStr(super.readLine());
    super.printStr(">\n");
  }
}
