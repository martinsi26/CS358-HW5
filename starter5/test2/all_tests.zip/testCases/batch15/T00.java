// empty switch statement, no default

class Main extends Lib {
  public void main() {
      for (int i = 0; i < 20; i++) {
	  switch (i*3) {
	  }
      }
      super.printStr("Done with Test 0\n");
  }
}

