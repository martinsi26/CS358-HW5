package errorMsg;

public class NegativeIndexWarning extends CompWarning
{
    public NegativeIndexWarning()
    {
        super("Array index cannot be negative");
    }
}
