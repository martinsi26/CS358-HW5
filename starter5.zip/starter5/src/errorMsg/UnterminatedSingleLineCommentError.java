package errorMsg;

public class UnterminatedSingleLineCommentError extends CompError
{
    public UnterminatedSingleLineCommentError()
    {
        super("unterminated single line comment");
    }
}
