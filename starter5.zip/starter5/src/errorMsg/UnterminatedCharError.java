package errorMsg;

public class UnterminatedCharError extends CompError
{
    public UnterminatedCharError()
    {
        super("unterminated character literal");
    }
}
