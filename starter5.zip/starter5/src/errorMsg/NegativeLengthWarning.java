package errorMsg;

public class NegativeLengthWarning extends CompWarning
{
    public NegativeLengthWarning()
    {
        super("Array length cannot be negative");
    }
}
